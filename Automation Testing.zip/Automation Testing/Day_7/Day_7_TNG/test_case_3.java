package Day_7_TNG;

import org.testng.annotations.Test;

public class test_case_3 {
  @Test
  public void f() {
  }
}
