package Day_7_TNG;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class test_case_1 {
  @Test(dataProvider = "login")
  public void login(String eid, String pwd, String er) {
 
	  System.out.println(eid+ pwd+ er);
	  Assert.assertEquals("Girish", er);
  }
  
  @DataProvider(name="login")
  public String[][] get_testdata()
  {
	  String[][] logintest ={
			  {"giris@gmail.com","mynew@55","Girish"},{"giris@gmail.com","mynew@55","Girirsh1"}
			  
	  };
	return logintest;
	  
  }
  
}
