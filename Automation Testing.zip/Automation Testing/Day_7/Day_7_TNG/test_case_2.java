package Day_7_TNG;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Day_6_a.login_test;

public class test_case_2 extends login_test  {
  
	@Test(dataProvider = "login")
  public void login(String eid, String pwd, String ex) {
	  
	  launchBrowser("http://demowebshop.tricentis.com/");
	  
	  this.email =eid;
	  this.password = pwd;
	  login();
	  this.ex = ex;
	  login_msg();
	  Assert.assertEquals(ex, ac);
  }
	
	@DataProvider(name="login")
	  public String[][] get_testdata()
	  {
		  String[][] logintest ={
				  {"girej@gmail.com","gmail.com","girej@gmail.com"},{"giris@gmail.com","mynew@55","Girirsh1"}
				  
		  };
		return logintest;
		  
	  }
	
}
