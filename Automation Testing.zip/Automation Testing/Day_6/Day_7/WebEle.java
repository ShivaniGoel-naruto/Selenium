package Day_7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebEle {

	public  String keyword, xpath, testdata,testResult, p_or_f;

	public static String av;
	
	static WebDriver dr;
	
	public static void launch_browser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		 dr = new ChromeDriver();
		dr.get(url);
		
	}
	
	public static void enterdata_button(String x_path, String data)
	{
		dr.findElement(By.xpath(x_path)).sendKeys(data);
	}
	
	public static void click_button(String xpath)
	{
		dr.findElement(By.xpath(xpath)).click();
	}
	
	public static String verify(String xpath, String ev)
	{
		av = dr.findElement(By.xpath(xpath)).getText();
		
		if(ev.equals(av))
			return "Pass";
		
		else
			return "fail";
	}
}
