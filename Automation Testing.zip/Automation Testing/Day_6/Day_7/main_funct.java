package Day_7;

import java.util.ArrayList;

public class main_funct extends all_methods {

	//WebEle wb = new WebEle();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<WebEle> arr = read_excel();
		
		for(WebEle e : arr)
		{
			System.out.println(e.keyword+e.testdata+e.xpath);
			switch(e.keyword)
			{
			case "launch_browser":
				launch_browser(e.testdata);
				break;
				
			case "enterdata_email":
				enterdata_button(e.xpath, e.testdata);
				break;
				
			case "enterdata_pass":
				enterdata_button(e.xpath, e.testdata);
				break;
				
			case "click_button":
				click_button(e.xpath);
				break;
				
			case "verify":
				String ver = verify(e.xpath, e.testdata);
				writeExcel(ver);
				break;

			}
		}
		
	}

}
