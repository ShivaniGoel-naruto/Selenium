package Day_7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class all_methods extends WebEle{

	static ArrayList <WebEle> we = new ArrayList<WebEle>();
	static File f;
	static XSSFWorkbook wb;
	static XSSFSheet sh;
	
	
	
	public static ArrayList<WebEle> read_excel()
	{
		
		try
		{
		 f = new File("D:\\test_data.xlsx");
		FileInputStream fis = new FileInputStream(f);
		 wb = new XSSFWorkbook(fis);
		 sh = wb.getSheet("Sheet1");
		
		for(int i=1;i<=5;i++)
		{
			WebEle w1= new WebEle();
		XSSFRow row =sh.getRow(i);
		
		XSSFCell cell = row.getCell(1);
		w1.keyword= cell.getStringCellValue();
		
		 cell = row.getCell(2);
		w1.xpath =  cell.getStringCellValue();
		
		 cell = row.getCell(3);
		w1.testdata = cell.getStringCellValue();
	
		we.add(w1);
		
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return we;
	}
		public static void writeExcel( String data)
		{
			
			
			try{
			FileOutputStream fos=new FileOutputStream(f);
			
			XSSFRow row =sh.getRow(5);
			XSSFCell cell = row.createCell(4);
			cell.setCellValue(data);
			
			wb.write(fos);
			}
			catch(Exception e)
			{
				System.out.println();
			}
			
		}
	
	
	
}
