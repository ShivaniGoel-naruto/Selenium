package TestNG_Day_6;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Day_6_a.login_test;

public class Login_TC_report extends login_test{
	
	
	@BeforeMethod
	public void launchBrowser()
	{
		launchBrowser("http://demowebshop.tricentis.com/");
	}	
  @Test
  public void tc1() {
	  
	  this.email ="girej@gmail.com";
	  this.password = "gmail.com";
	  login();
	  this.ex = email;
	  login_msg();
	  Assert.assertEquals(ex, ac);
	 
  }
  
  @Test
  public void tc2() {
	  
	  
	  this.email ="girej@gmail.com";
	  this.password = "gmai";
	  login();
	  this.ex = "Login was unsuccessful. Please correct the errors and try again.";
	  login_msg();
	  Assert.assertEquals(ex, ac);
  }  
  
  @Test
  public void tc3() {
	  
	  this.email ="girej";
	  this.password = "gmail.com";
	  login();
	  this.ex = "Please enter a valid email address.";
	  login_msg();
	  System.out.println(ac);
	  Assert.assertEquals(ex, ac);
  }
  
  
  @AfterMethod
  public void cleanup()
  {
	  close();
  }
}
