package TestNG_Day_6;

import org.testng.Assert;
import org.testng.annotations.Test;

import Day_6_a.login_test;

public class TC_login extends login_test {
  @Test
  public void tc1() {
	  
	  this.email ="girej@gmail.com";
	  this.password = "gmail.com";
	  login();
	  this.ex = email;
	  
	  Assert.assertEquals(ex, ac);
	  close();
  }
  
  @Test
  public void tc2() {
	  
	  this.email ="girej@gmail.com";
	  this.password = "gmail.com";
	  login();
	  this.ex = "girej@gmail.co";
	  
	  Assert.assertEquals(ex, ac);
	  
	  close();
  }
}
