package TestNG_Day_6;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Before_after_method {
 
	@AfterClass
	public void AC() {
		  System.out.println("A");
			}
	
	@BeforeClass
	public void BC() {
		  System.out.println("A");
			}
	
	@AfterMethod
	public void AM() {
		  System.out.println("After Method ");
			}
		
	@BeforeMethod
	public void BM() {
		  System.out.println("Before Method");
			}
	
	@Test(priority =6)
  public void A() {
  System.out.println("A");
	}
  

	@Test(priority =3)
  public void a() {
  System.out.println("a");
	}
  
	
	@Test(priority =1)
  public void z() {
  System.out.println("z");
	}
  

	/*@Test
  public void A() {
  System.out.println("A");
	}
  

	@Test
  public void a() {
  System.out.println("a");
	}
  
	
	@Test
  public void z() {
  System.out.println("z");
	}
  */
}
