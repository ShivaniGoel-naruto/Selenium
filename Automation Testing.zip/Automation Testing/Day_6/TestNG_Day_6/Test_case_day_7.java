package TestNG_Day_6;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Test_case_day_7 
{
	
  @Test(dataProvider ="logindataprovider")
  public void login(String eid, String pwd, String er) {
  
	  System.out.println(eid+" "+pwd+" "+er);
	  Assert.assertEquals("Girish", er);
  }
  
  @DataProvider(name="logindataprovider")
  public String[][] get_testdata()
  {
	  String[][] logintestdata ={
			  
			  {"girishinid@gmail.com","mynewnp@55","Girirsh"},
			  {"girishinid@gmail.com","mynewnp@55","Girirsh1"}
	  };
	  return logintestdata;
  }
}
