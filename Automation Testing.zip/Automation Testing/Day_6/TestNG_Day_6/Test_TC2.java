package TestNG_Day_6;

import org.testng.annotations.Test;

import day_6.launch_browser;

public class Test_TC2 extends launch_browser{
	String url = "http://demo.guru99.com/test/delete_customer.php";
	
	
  @Test
  public void tc1() {
	  

		//launch_browser br = new launch_browser();
		launchBrowser(url);
		method_1();
		accept();
		
		// reject
		
  }
  


@Test
  public void tc2()
  {

		launch_browser br = new launch_browser();
		
			br.launchBrowser(url);
		method_1();
		reject();
  }
}
