package TestNG_Day_6;

import org.testng.annotations.Test;

public class Test_TC1_1_1 {
 
 
  @Test
  public void tc1() {
	  
	  System.out.println("tc1");
	  tc2();
  }
 
 
 public void tc2() {
	  
	  System.out.println("tc2");
  }
  
  @Test
  public void tc3() {
 	  
 	  System.out.println("tc3");
   }  

}
