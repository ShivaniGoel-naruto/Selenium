package Day_6_a;

import org.openqa.selenium.By;

import day_6.launch_browser;

public class login_test extends launch_browser {

	protected String email;
	protected String password;
	protected String ac;
	protected String ex;
	boolean x=false, y=false;
	//WebDriver dr;
	public void login()
	{
		
		dr.findElement(By.className("ico-login")).click();
		
		dr.findElement(By.name("Email")).sendKeys(email);
		dr.findElement(By.name("Password")).sendKeys(password);
		
		dr.findElement(By.cssSelector("input[value='Log in']")).click();
				
		ac = dr.findElement(By.className("account")).getText();		
	}
	
	public void login_msg()
	{
		//ac = dr.findElement(By.className("account")).getText();	
		
		try {
			x= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).isDisplayed();
			
		}
		catch(Exception e)
		{
			System.out.println("");
		}
		if (x==true)
		{
			ac = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		
			//
		}
		else
		{
			try
			{
				y=  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
			}
			catch(Exception e)
			{
				System.out.println("please handle [email id is incorrect]");
			}
			
			if(y==true)
			{
				ac=  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				System.out.print(ac);
			}
			else
				ac = dr.findElement(By.className("account")).getText();	
		}
		System.out.println(ac);
		
	}
	
		public void close()
	{
		dr.close();
	}
	
	
}
