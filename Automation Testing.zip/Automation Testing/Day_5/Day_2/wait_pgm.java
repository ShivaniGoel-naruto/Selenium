package Day_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class wait_pgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://facebook.com/");
		
		WebDriverWait wt = new WebDriverWait(dr,10);
		
		wt.until(ExpectedConditions.elementToBeClickable(By.id("u_0_2")));
		dr.findElement(By.id("u_0_2")).click();
		
		dr.navigate().back();
		dr.navigate().forward();
		dr.navigate().refresh();
		dr.navigate().to("URL"); /// Equivalent to dr.get()
		
	}

}
