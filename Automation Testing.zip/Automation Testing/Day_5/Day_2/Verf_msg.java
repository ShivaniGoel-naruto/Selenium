package Day_2;

public class Verf_msg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
