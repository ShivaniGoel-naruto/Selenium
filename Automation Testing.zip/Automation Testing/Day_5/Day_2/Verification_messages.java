package Day_2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verification_messages {

	static String email;
	static String password;
	static String expvalue;
	static String value, status;
	static boolean x=false;
	static boolean y=false;
	public static void main(String[] args)   {
		// TODO Auto-generated method stub

		{
			System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
				WebDriver dr = new ChromeDriver();
				File f = new File("D:\\Book_selenium - Copy.xlsx");
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(f);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				XSSFWorkbook wb = null;
				try {
					wb = new XSSFWorkbook(fis);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				XSSFSheet sh = wb.getSheet("Sheet1");
				System.out.print("1");
				
				for(int row=1;row<=2;row++)
				{
				
								
				
					System.out.print("2");
					dr.get("http://demowebshop.tricentis.com/");
					/*String t2 = "Demo Web Shop";
					String t = dr.getTitle(); 
					if(t.equals(t2))
						System.out.print("PAss");
					else
						System.out.print("Fail");*/
					
					dr.findElement(By.className("ico-login")).click();
					System.out.print("3");
					readExcel(row, sh);
					System.out.print("4");
				dr.findElement(By.name("Email")).sendKeys(email);
				System.out.print("5");
				dr.findElement(By.name("Password")).sendKeys(password);
				dr.findElement(By.cssSelector("input[value='Log in']")).click();
				try
				{
					System.out.print("6");
				 y = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
					System.out.print(y);
				}
				catch(Exception e)
				{
					//System.out.print(e);
					System.out.print(y);
				}
				try
				{
					System.out.print("6");
				x = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).isDisplayed();
				System.out.print(x);
				}
				catch(Exception e)
				{
					System.out.print("Please catch");
					System.out.print(x);
				}
				
				
				System.out.print("6A");
				// value = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				if(x==true)
				value = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
				if(y)
				value = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
/*System.out.print("6A");
				
				System.out.print("6B");
				if(y)*/ 
				System.out.print(value);
				System.out.print("7");
				evaluate(value);
				System.out.print("8");
				//String status=evaluate(value);
				writeExcel(f,sh,row, status, wb,value );
			//	dr.close();
					
			//	/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span
				
			//	/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span
				
			//	/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li
				
				
			//	value = dr.findElement(By.className("account")).getText();
			//	String status=evaluate(value);
			//	writeExcel(f,sh,row, status, wb,value );
			//	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
				
				
				System.out.print("2");
				
				
				
				//dr.close();
				}
				//dr.close();
		}}

			public static void readExcel(int row_1, XSSFSheet sh)
			{
			
				try{	
				
					XSSFRow row =sh.getRow(row_1);
					
					XSSFCell cell = row.getCell(0);
					email =  cell.getStringCellValue();
					
					 cell = row.getCell(1);
					password =  cell.getStringCellValue();
					
					 cell = row.getCell(2);
					expvalue = cell.getStringCellValue();

					
				}
				catch(Exception e)
				{
					//System.out.print(e);
				}
				
			}
			
			public static void evaluate(String msg)
			{
				if(msg.equals(expvalue))
					status ="pass";
				else
					status = "fail";
				
			}
			public static void writeExcel(File f,XSSFSheet sh, int ro, String status, XSSFWorkbook wb, String value)
			{
				try{
				FileOutputStream fos=new FileOutputStream(f);
				
				XSSFRow row =sh.getRow(ro);
				XSSFCell cell = row.createCell(4);
				cell.setCellValue(status);
				
				 row =sh.getRow(ro);
				 cell = row.createCell(3);
				cell.setCellValue(value);
				
				wb.write(fos);
				}
				catch(Exception e)
				{
					System.out.println();
				}
				
			}

	}


