package day_6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;

public class launch_browser {

	public WebDriver dr;
	public void launchBrowser (String url)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		 dr = new ChromeDriver();
		dr.get(url);
		//return dr;

	}
	
	public void method_1()
	{
		dr.findElement(By.cssSelector("input[type='text']")).sendKeys("dnjfehf");
		dr.findElement(By.cssSelector("input[type='submit']")).click();
	}
	
	public void accept()
	{
		String str = dr.switchTo().alert().getText();
		System.out.println(str);
		dr.switchTo().alert().accept();
		str = dr.switchTo().alert().getText();
		System.out.println(str);
		
		dr.switchTo().alert().accept();
		
		dr.close();
	}
	
	
	public void reject()
	{
		String str = dr.switchTo().alert().getText();
		System.out.println(str);
		dr.switchTo().alert().dismiss();
		dr.close();
	}
	
	public static void main(String arr[])
	{
		System.out.print("I am  main");
	}
}
