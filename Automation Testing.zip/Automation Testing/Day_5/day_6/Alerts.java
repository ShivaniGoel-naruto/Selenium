package day_6;

public class Alerts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		launch_browser br = new launch_browser();
		
		String url = "http://demo.guru99.com/test/delete_customer.php";
		
		 br.launchBrowser(url);
		br.method_1();
		br.accept();
		
		// reject
		br.launchBrowser(url);
		br.method_1();
		br.reject();
		
		
	}

	
	

}
