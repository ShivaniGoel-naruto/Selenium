package Day_2;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Copy_paste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://facebook.com/");
		
		WebElement we1=	dr.findElement(By.name("firstname"));
		
		Actions act = new Actions(dr);
		Action act1 = act
				.moveToElement(we1)
				.click(we1)
				.sendKeys("java")
				.keyDown(we1, Keys.CONTROL)
				.sendKeys("A")
				.sendKeys("c")
				.keyUp(we1, Keys.CONTROL)
				.build();
		act1.perform();
		
		WebElement we2 = dr.findElement(By.name("lastname"));
		
		Actions act3 = new Actions(dr);
		Action act2 = act3
				.moveToElement(we2)
				.click(we2)
				.keyDown(we2, Keys.CONTROL)
				.sendKeys(we2,"v")
				.keyUp(we2, Keys.CONTROL)
				.build();
		act2.perform();
				
	}

}
