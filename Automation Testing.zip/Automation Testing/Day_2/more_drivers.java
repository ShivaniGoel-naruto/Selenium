import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class more_drivers {

	public static void main(String[] args) {
		
	/*	System.setProperty("webdriver.ie.driver", "D:\\Drivers\\IEDriverServer.exe");
		WebDriver dr = new InternetExplorerDriver();
		dr.get("https://www.facebook.com");
		*/
		System.setProperty("webdriver.gecko.driver", "D:\\Drivers\\geckodriver.exe");
		WebDriver dr = new FirefoxDriver();
		dr.get("https://www.facebook.com");
		
		
	}
}

