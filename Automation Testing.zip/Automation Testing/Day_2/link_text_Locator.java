import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class link_text_Locator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
		
		//dr.findElement(By.linkText("Forgotten account?")).click();
		
	//	dr.findElement(By.cssSelector("input[value='Log In']")).click();
		
	//	dr.findElement(By.cssSelector("label[class='uiButton uiButtonConfirm']")).click();
	//	dr.findElement(By.cssSelector("input#u_0_a")).click();
		
	//	String str = dr.findElement(By.xpath("//*[contains(text(),'Create ')]")).getText();
		String str = dr.findElement(By.xpath("//input[@name ='firstname']//following::input[1]")).getText();
		System.out.print(str);
		
		
	}

}
