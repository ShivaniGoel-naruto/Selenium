import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		String t2 = "Demo Web Shop";
		String t = dr.getTitle(); 
		if(t.equals(t2))
			System.out.print("PAss");
		else
			System.out.print("Fail");
		
		 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		String t1= dr.getTitle();
		
		if(t1.equals(t2))
			System.out.print("PAss");
		else
			System.out.print("Fail");
		
		List <WebElement> rb =dr.findElements(By.name("Gender"));
		rb.get(0).click();
		
		dr.findElement(By.name("FirstName")).sendKeys("girish");
		dr.findElement(By.name("LastName")).sendKeys("India");
		dr.findElement(By.name("Email")).sendKeys("girej@gmail.com");
		
		dr.findElement(By.name("Password")).sendKeys("gmail.com");
		dr.findElement(By.name("ConfirmPassword")).sendKeys("gmail.com");
		
		dr.findElement(By.id("register-button")).click();
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	
		dr.close();
	}
	

}
