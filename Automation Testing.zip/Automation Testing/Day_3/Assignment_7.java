import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		
		dr.findElement(By.cssSelector("input[name='user_login']")).sendKeys("anbff");
		dr.findElement(By.cssSelector("input[name='user_password']")).sendKeys("djkfkfhdkjhf");
		
		dr.findElement(By.cssSelector("input[name='first_name']")).sendKeys("djh");
		
		dr.findElement(By.cssSelector("input[name='last_name']")).sendKeys("dsjhd");
		
		dr.findElement(By.cssSelector("input[name='email']")).sendKeys("dbb@gmail.com");
		
		dr.findElement(By.cssSelector("input[name='city']")).sendKeys("Mandiya");
		

		WebElement we1 = dr.findElement(By.name("state_id"));
		Select sel1 = new Select(we1);
		sel1.selectByVisibleText("Vermont");
		
		 we1 = dr.findElement(By.name("country_id"));
		 sel1 = new Select(we1);
		sel1.selectByVisibleText("Aruba");
		
		 we1 = dr.findElement(By.name("gender_id"));
		 sel1 = new Select(we1);
		sel1.selectByVisibleText("Male");
		
		
		dr.findElement(By.cssSelector("input[name='Insert']")).click();
		dr.findElement(By.name("s_keyword")).sendKeys("anbff");
		dr.findElement(By.name("Button_DoSearch")).click();
		String name=dr.findElement(By.xpath("//table[@class=\"Grid\"]//td[2]")).getText();
		if(name.equals("anbff")) 
		System.out.println("Pass");
		
		
		
	}

}
