import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		String t2 = "Demo Web Shop";
		String t = dr.getTitle(); 
		if(t.equals(t2))
			System.out.print("PAss");
		else
			System.out.print("Fail");
		dr.findElement(By.className("ico-login")).click();
		
		dr.findElement(By.name("Email")).sendKeys("girej@gmail.com");
		dr.findElement(By.name("Password")).sendKeys("gmail.com");
		
		dr.findElement(By.cssSelector("input[value='Log in']")).click();
		String email = dr.findElement(By.className("account")).getText();
		System.out.println();
		System.out.print(email);
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		dr.close();
		
		
		
	}

}
