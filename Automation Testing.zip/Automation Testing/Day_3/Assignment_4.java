import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class Assignment_4 {
	static String email;
	static String password;
	static String expvalue;
	static String value;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		try
		{
		File f = new File("D:\\Book_selenium.xlsx");
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		
		for(int row=1;row<=3;row++)
		{
			dr.get("http://demowebshop.tricentis.com/");
			String t2 = "Demo Web Shop";
			String t = dr.getTitle(); 
			if(t.equals(t2))
				System.out.print("PAss");
			else
				System.out.print("Fail");
			
			dr.findElement(By.className("ico-login")).click();
			
			readExcel(row, sh);
			
		dr.findElement(By.name("Email")).sendKeys(email);
		
		dr.findElement(By.name("Password")).sendKeys(password);
		dr.findElement(By.cssSelector("input[value='Log in']")).click();
		value = dr.findElement(By.className("account")).getText();
		String status=evaluate(value);
		writeExcel(f,sh,row, status, wb );
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		
		}
		}
		
		catch(Exception e)
		{
		
			System.out.print(e);
		}
		
		dr.close();
		}

	public static void readExcel(int row_1, XSSFSheet sh)
	{
	
		try{	
		
			XSSFRow row =sh.getRow(row_1);
			
			XSSFCell cell = row.getCell(0);
			email =  cell.getStringCellValue();
			
			 cell = row.getCell(1);
			password =  cell.getStringCellValue();
			
			 cell = row.getCell(2);
			expvalue = cell.getStringCellValue();

			
		}
		catch(Exception e)
		{
			System.out.print(e);
		}
		
	}
	
	public static String evaluate(String msg)
	{
		if(msg.equals(expvalue))
			return "pass";
		else
			return "fail";
		
	}
	public static void writeExcel(File f,XSSFSheet sh, int ro, String status, XSSFWorkbook wb)
	{
		try{
		FileOutputStream fos=new FileOutputStream(f);
		
		XSSFRow row =sh.getRow(ro);
		XSSFCell cell = row.createCell(3);
		cell.setCellValue(status);
		
		wb.write(fos);
		}
		catch(Exception e)
		{
			System.out.println();
		}
		
	}

}
