import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String t2 = "Online Bookstore";
		String t = dr.getTitle(); 
		if(t.equals(t2))
			System.out.print("PAss");
		else
			System.out.print("Fail");
		
		 dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[2]/tbody/tr[1]/td/a")).click();
		
		 dr.findElement(By.className("TopMenuLink")).click();
		 /*try {
			dr.wait(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		 dr.close();

	}

}
