import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment_5 {

	public static void main(String[] args)
	{
		String qty ="2";
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		
		 dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[2]/tbody/tr[1]/td/a")).click();
		 dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		 //    /html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a
		 //		/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[3]/td[2]/b/a
		 
		// dr.findElement(By.tagName("h1")).getText();
		 System.out.print( dr.findElement(By.tagName("h1")).getText());
		 
		 dr.findElement(By.name("quantity")).clear();
		 dr.findElement(By.name("quantity")).sendKeys(qty);
		 dr.findElement(By.name("Insert1")).click();
		 
		 
	//	 /html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[2]
		 
		String price= dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[2]")).getText();
		//System.out.println(price);
		price = price.substring(1);
		//System.out.print(price);
		double price1 = Double.parseDouble(price);
		//System.out.print(price1);
		
		
		double quantity = Double.parseDouble(qty);
		 
		 double total = price1*quantity;
		 System.out.println();
		 System.out.println(total);
		 //System.out.print(total);
		 
		 //		/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]
		 
		 String ttl= dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText();
			//System.out.println(price);
			ttl = ttl.substring(1);
			//System.out.print(price);
			double tyl = Double.parseDouble(ttl);
		System.out.print(tyl);
		if(tyl==total)
		System.out.println("Verified");
		else
			System.out.print("not Verified");
		
	}

}
